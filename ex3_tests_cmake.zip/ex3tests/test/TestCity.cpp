
#include "TestCity.h"

/*
 * Test for checking for passenger input, by
 * checking if a passenger was added
 * to the TaxiCenter
 */
TEST_F(TestCity, PassengerCalls) {
    int count = 0;
    Passenger p = Passenger();
    Graph *grid = new Grid(5, 5);
    TaxiCenter tc = TaxiCenter(grid);
    Trip t1 = Trip(77,3,3,1,1,2,3);
    Trip t2 = Trip(10,2,2,3,4,1,7);
    tc.addTrip(t1);
    tc.addTrip(t2);
    vector<Trip>::iterator it=tc.getTrips().begin();
    while (it!=tc.getTrips().end()){
        count += (*(it)).getNumOfPassengers();
        it++;
    }

    int count1 = count;
    c.CallTaxiCenter(p);
    while (it!=tc.getTrips().end()){
        count += (*(it)).getNumOfPassengers();
    }

    int count2 = count;
    //Should be +1
    EXPECT_FALSE(count1 == count2) << "Didn't add new passenger.";
}
