
#ifndef EX2_TESTPOINT_H
#define EX2_TESTPOINT_H

#include <gtest/gtest.h>
#include "../src/Point.h"
/*
 * Test class for point.
 */
class TestPoint: public::testing::Test {
protected:
    Point point;
public:
    void SetUp() {
        cout << "SET UP POINT\n";
    }
    void TearDown() {
        cout << "Tearing Down Point\n";
    } ///: (point = new Point(1, 2)) {}
};
#endif
