#ifndef EX2_TESTTAXI_H
#define EX2_TESTTAXI_H

#include "../src/Taxi.h"

/*
 * Test class for taxi.
 */
class TestTaxi: public::testing::Test {

};


#endif //EX2_TESTTAXI_H
